#pragma once
#include "Graphics.h"
#include "Keyboard.h"
#include "Character.h"
#include "GameTimer.h"

static WCHAR *sc_helloWorld = L"Jee";
static WCHAR buf[10];
PCWSTR uriarr[] ={ 
	L"p1_walk01.png", L"p1_walk02.png", L"p1_walk03.png", L"p1_walk04.png", L"p1_walk05.png", L"p1_walk06.png", L"p1_walk07.png", L"p1_walk08.png", L"p1_walk09.png", L"p1_walk10.png", L"p1_walk11.png", };
class GoodmanEngine {

public:
	GoodmanEngine(HINSTANCE instance);
	~GoodmanEngine();

	// rekister�id��n window class aka mainwindow
	HRESULT Initialize();
	// p�� message loop, translate/dispatch messaget
	void RunMessageLoop();
	// prosessoi kaikki viestit jotka l�hetetty ikkunalle
	static LRESULT CALLBACK WndProc(HWND hWnd,UINT message,WPARAM wParam,LPARAM lParam);

	void drawBitmap(PCWSTR uri);

	void drawText();

	void makeActionForKey(KEYSTROKES key);

private:
	double x, y;
	int index;
	HWND m_hwnd;
	HINSTANCE m_windowsInstance;
	Graphics m_graphics;
	Keyboard m_keyboard;
	Character m_character;
	GameTimer timer;
};

void GoodmanEngine::drawBitmap(PCWSTR uri) {
	auto tupleResult = m_character.loadImageFromFile(uri, m_graphics.getRenderTarget());
	auto hrCode = std::get<HRESULT>(tupleResult);

	if (hrCode == S_OK) {
		auto bitmap = std::get<ID2D1Bitmap*>(tupleResult);
		m_graphics.getRenderTarget()->BeginDraw();
		m_graphics.getRenderTarget()->Clear(D2D1::ColorF(D2D1::ColorF::White));

		m_graphics.getRenderTarget()->DrawBitmap(bitmap,
			D2D1::RectF(
				x, y, bitmap->GetSize().width + x , bitmap->GetSize().height + y
			), 0.5f, D2D1_BITMAP_INTERPOLATION_MODE::D2D1_BITMAP_INTERPOLATION_MODE_NEAREST_NEIGHBOR, D2D1::RectF(0.0f, 0.0f, bitmap->GetSize().width, bitmap->GetSize().height));

		m_graphics.getRenderTarget()->EndDraw();
	}
}

GoodmanEngine::GoodmanEngine(HINSTANCE instance) {
	m_windowsInstance = instance;
	x = y = 0.0;
	index = 0;
}

GoodmanEngine::~GoodmanEngine() { }
// Luodaan �ppi ja laitteistoriippumattomatta resurssit
HRESULT GoodmanEngine::Initialize()
{
	HRESULT hr;

	// luodaan laitteistoriippumattomat resurssit
	hr = m_graphics.CreateDeviceIndependentResources();

	if (SUCCEEDED(hr))
	{
		// rekister�id��n windows luokka
		WNDCLASSEX wcex = { sizeof(WNDCLASSEX) };
		wcex.style = CS_HREDRAW | CS_VREDRAW;
		wcex.lpfnWndProc = GoodmanEngine::WndProc;
		wcex.cbClsExtra = 0;
		wcex.cbWndExtra = sizeof(LONG_PTR);
		wcex.hInstance = m_windowsInstance;
		wcex.hbrBackground = (HBRUSH)COLOR_WINDOW;
		wcex.lpszMenuName = NULL;
		wcex.hCursor = LoadCursor(NULL, IDI_APPLICATION);
		wcex.lpszClassName = L"GoodmanEngine";

		RegisterClassEx(&wcex);


		// haetaan j�rjestelm�n dpi, pikselit
		FLOAT dpiX, dpiY;

		m_graphics.getFactory()->GetDesktopDpi(&dpiX, &dpiY);

		m_hwnd = CreateWindow(
			L"GoodmanEngine",
			L"paskaap",
			WS_OVERLAPPEDWINDOW,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			static_cast<UINT>(ceil(640.f * dpiX / 96.f)),
			static_cast<UINT>(ceil(480.f * dpiY / 96.f)),
			NULL,
			NULL,
			m_windowsInstance,
			this
		);
		hr = m_hwnd ? S_OK : E_FAIL;
		if (SUCCEEDED(hr))
		{
			ShowWindow(m_hwnd, SW_SHOWNORMAL);
			UpdateWindow(m_hwnd);
		}
	}

	return hr;
}

// main message loop

void GoodmanEngine::drawText() {
	static const WCHAR msc_fontName[] = L"Verdana";
	static const FLOAT msc_fontSize = 50;
	IDWriteFactory* m_pDWriteFactory = NULL;
	IDWriteTextFormat* m_pTextFormat = NULL;

	HRESULT hr = DWriteCreateFactory(
		DWRITE_FACTORY_TYPE_SHARED,
		__uuidof(m_pDWriteFactory),
		reinterpret_cast<IUnknown **>(&m_pDWriteFactory)
	);
	
	if(SUCCEEDED(hr)){
	hr = m_pDWriteFactory->CreateTextFormat(
		msc_fontName,
		NULL,
		DWRITE_FONT_WEIGHT_NORMAL,
		DWRITE_FONT_STYLE_NORMAL,
		DWRITE_FONT_STRETCH_NORMAL,
		msc_fontSize,
		L"", //locale
		&m_pTextFormat
	);
	}
	if (SUCCEEDED(hr)) {

		m_pTextFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);

		m_pTextFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
	}


	// Retrieve the size of the render target.
	D2D1_SIZE_F renderTargetSize = m_graphics.getRenderTarget()->GetSize();

	m_graphics.getRenderTarget()->BeginDraw();

	m_graphics.getRenderTarget()->SetTransform(D2D1::Matrix3x2F::Identity());

	//m_graphics.getRenderTarget()->Clear(D2D1::ColorF(D2D1::ColorF::White));

	ID2D1Brush* brush = NULL;
	ID2D1SolidColorBrush* jee = NULL;
	m_graphics.getRenderTarget()->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::Black, 1.0f), &jee);
	//KORJAA
	m_graphics.getRenderTarget()->DrawTextW(
		buf,
		10,
		m_pTextFormat,
		D2D1::RectF(0, 0, renderTargetSize.width, renderTargetSize.height),
		jee
	);

	hr = m_graphics.getRenderTarget()->EndDraw();


}
void GoodmanEngine::RunMessageLoop()
{
	MSG msg;
	GameTimer timer;

	m_graphics.CreateDeviceResources(m_hwnd);

	bool trigger = true;
	PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE);

	while (msg.message != WM_QUIT) {
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else {
			_itow_s((int)timer.delta(), buf, sizeof(buf) / sizeof(WCHAR), 10);
			
			if (timer.delta() >= timer.getClockRate()) {
				//drawBitmap(L"p1_walk01.png");
				timer.resetClock();
			//	drawText();
			}
		
			timer.clockTick();
		}
	}

}

void GoodmanEngine::makeActionForKey(KEYSTROKES key) {
	switch (key) {
		case KEYSTROKES::left:
			x -= 3.5f;
			if (timer.delta() >= timer.getClockRate()) {
				drawBitmap(uriarr[index]);
				index = index == 0 ? 11 : index-1;
				timer.resetClock();
			}
			timer.clockTick();
			break;
		case KEYSTROKES::right:
			x += 3.5f;
			if(timer.delta() >= timer.getClockRate()) {
				drawBitmap(uriarr[index]);
				index = index < 12 ? index + 1 : 0;
				timer.resetClock();
			}
			timer.clockTick();
			break;
	}
}
LRESULT CALLBACK GoodmanEngine::WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LRESULT result = 0;

	if (message == WM_CREATE)
	{
		LPCREATESTRUCT pcs = (LPCREATESTRUCT)lParam;
		GoodmanEngine *engine = (GoodmanEngine *)pcs->lpCreateParams;

		::SetWindowLongPtrW(
			hwnd,
			GWLP_USERDATA,
			PtrToUlong(engine)
		);

		result = 1;
	}
	else
	{
		GoodmanEngine *engine = reinterpret_cast<GoodmanEngine *>(static_cast<LONG_PTR>(
			::GetWindowLongPtrW(
				hwnd,
				GWLP_USERDATA
			)));

		bool wasHandled = false;

		if (engine)
		{
			switch (message)
			{
			case WM_SIZE:
			{
				UINT width = LOWORD(lParam);
				UINT height = HIWORD(lParam);
				engine->m_graphics.OnResize(width, height);
			}
			result = 0;
			wasHandled = true;
			break;

			case WM_DISPLAYCHANGE:
			{
				InvalidateRect(hwnd, NULL, FALSE);
			}
			result = 0;
			wasHandled = true;
			break;

			case WM_PAINT:
			{
			//	engine->OnRender();
				ValidateRect(hwnd, NULL);
			}
			result = 0;
			wasHandled = true;
			break;

			//keyboard handle
			case WM_KEYDOWN:
			{
				auto key = engine->m_keyboard.handleInput(wParam);
				engine->makeActionForKey(key);
				break;
			}
			case WM_DESTROY:
			{
				PostQuitMessage(0);
			}
			result = 1;
			wasHandled = true;
			break;
			}
		}

		if (!wasHandled)
		{
			result = DefWindowProc(hwnd, message, wParam, lParam);
		}
	}

	return result;
}
