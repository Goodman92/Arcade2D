#pragma once

class BaseLevel {

};