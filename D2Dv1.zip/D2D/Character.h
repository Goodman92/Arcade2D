#pragma once
#include <tuple>

class Character {

public:
	Character();
	std::tuple<HRESULT, ID2D1Bitmap*> LoadCharacterFromFile(ID2D1RenderTarget *pRenderTarget, IWICImagingFactory *pIWICFactory, PCWSTR uri, UINT destinationWidth, UINT destinationHeight, ID2D1Bitmap **ppBitmap);

	std::tuple<HRESULT, ID2D1Bitmap*> loadImageFromFile(PCWSTR uri, ID2D1RenderTarget *pRenderTarget);
private:
	std::tuple<HRESULT, ID2D1Bitmap*> m_hrBitmapTuple;
};

Character::Character() {
	//auto m_hrBitmapTuple = std::make_tuple(S_FALSE, NULL);
}

std::tuple<HRESULT, ID2D1Bitmap*> Character::LoadCharacterFromFile(ID2D1RenderTarget *pRenderTarget, IWICImagingFactory *pIWICFactory2, PCWSTR uri2, UINT destinationWidth, UINT destinationHeight, ID2D1Bitmap **ppBitmap ) {
	return loadImageFromFile(L"p1_walk02.png", pRenderTarget);
	/*
	HRESULT hr = S_OK;
	IWICBitmapDecoder *pDecoder = NULL;
	IWICBitmapFrameDecode *pSource = NULL;
	IWICStream *pStream = NULL;
	IWICFormatConverter *pConverter = NULL;
	IWICBitmapScaler *pScaler = NULL;


	IWICImagingFactory *wicFactory = NULL;

	CoCreateInstance(
		CLSID_WICImagingFactory,
		NULL,
		CLSCTX_INPROC_SERVER,
		IID_IWICImagingFactory,
		(LPVOID*)&wicFactory);


	PCWSTR uri = L"p1_walk02.png";
	hr = wicFactory->CreateDecoderFromFilename(
		uri,
		NULL,
		GENERIC_READ,
		WICDecodeMetadataCacheOnLoad,
		&pDecoder
	);


	if (SUCCEEDED(hr)) {
		// Create the initial frame.
		hr = pDecoder->GetFrame(0, &pSource);
	}


	if (SUCCEEDED(hr)) {

		// Convert the image format to 32bppPBGRA
		// (DXGI_FORMAT_B8G8R8A8_UNORM + D2D1_ALPHA_MODE_PREMULTIPLIED).
		hr = wicFactory->CreateFormatConverter(&pConverter);

	}


	if (SUCCEEDED(hr)) {
		hr = pConverter->Initialize(
			pSource,
			GUID_WICPixelFormat32bppPBGRA,
			WICBitmapDitherTypeNone,
			NULL,
			0.f,
			WICBitmapPaletteTypeMedianCut
		);
	}
	ID2D1Bitmap* bmp = NULL;
	if (SUCCEEDED(hr))
	{

		// Create a Direct2D bitmap from the WIC bitmap.
		hr = pRenderTarget->CreateBitmapFromWicBitmap(
			pConverter,
			NULL,
			&bmp
		);

		auto a = bmp->GetSize().width;
		pRenderTarget->BeginDraw();
		pRenderTarget->DrawBitmap(bmp,
			D2D1::RectF(
				0.0f, 0.0f, bmp->GetSize().width, bmp->GetSize().height
			), 0.5f, D2D1_BITMAP_INTERPOLATION_MODE::D2D1_BITMAP_INTERPOLATION_MODE_NEAREST_NEIGHBOR, D2D1::RectF(0.0f, 0.0f, bmp->GetSize().width, bmp->GetSize().height));
		pRenderTarget->EndDraw();
	}
	if (pDecoder) {
		pDecoder->Release();
	}
	if (pSource) {
		pSource->Release();

	}
	if (pConverter) {
		pConverter->Release();
	}

	return hr;
	*/
}

std::tuple<HRESULT, ID2D1Bitmap*> Character::loadImageFromFile(PCWSTR uri, ID2D1RenderTarget *pRenderTarget) {
	HRESULT hr = S_OK;
	IWICBitmapDecoder *pDecoder = NULL;
	IWICBitmapFrameDecode *pSource = NULL;
	IWICStream *pStream = NULL;
	IWICFormatConverter *pConverter = NULL;
	IWICBitmapScaler *pScaler = NULL;

	IWICImagingFactory *wicFactory = NULL;

	CoCreateInstance(
		CLSID_WICImagingFactory,
		NULL,
		CLSCTX_INPROC_SERVER,
		IID_IWICImagingFactory,
		(LPVOID*)&wicFactory);


	//PCWSTR uri = L"p1_walk02.png";
	hr = wicFactory->CreateDecoderFromFilename(
		uri,
		NULL,
		GENERIC_READ,
		WICDecodeMetadataCacheOnLoad,
		&pDecoder
	);


	if (SUCCEEDED(hr)) {
		hr = pDecoder->GetFrame(0, &pSource);
	}

	if (SUCCEEDED(hr)) {
		// muutetaan kuva, transparenttia?
		hr = wicFactory->CreateFormatConverter(&pConverter);
	}


	if (SUCCEEDED(hr)) {
		hr = pConverter->Initialize(
			pSource,
			GUID_WICPixelFormat32bppPBGRA,
			WICBitmapDitherTypeNone,
			NULL,
			0.f,
			WICBitmapPaletteTypeMedianCut
		);
	}
	//ID2D1Bitmap* bmp = NULL;
	auto bmp2 = std::get<ID2D1Bitmap*>(m_hrBitmapTuple);
	//std::get<ID2D1Bitmap*>(m_hrBitmapTuple) = NULL;

	if (SUCCEEDED(hr))
	{
		//bitmapin alustus
		hr = pRenderTarget->CreateBitmapFromWicBitmap(
			pConverter,
			NULL,
			&bmp2
		);
		std::get<ID2D1Bitmap*>(m_hrBitmapTuple) = bmp2;
	/*
		pRenderTarget->BeginDraw();
		pRenderTarget->DrawBitmap(bmp2,
			D2D1::RectF(
				0.0f, 0.0f, bmp2->GetSize().width, bmp2->GetSize().height
			), 0.5f, D2D1_BITMAP_INTERPOLATION_MODE::D2D1_BITMAP_INTERPOLATION_MODE_NEAREST_NEIGHBOR, D2D1::RectF(0.0f, 0.0f, bmp2->GetSize().width, bmp2->GetSize().height));
		pRenderTarget->EndDraw();
				*/
	}
	if (pDecoder) {
		pDecoder->Release();
	}
	if (pSource) {
		pSource->Release();

	}
	if (pConverter) {
		pConverter->Release();
	}

	return m_hrBitmapTuple;
}
