#pragma once

enum KEYSTROKES {
	left = VK_LEFT,
	right = VK_RIGHT,
	undefined = 0
};
class Keyboard {

public:
	KEYSTROKES handleInput(WPARAM wParam) {
		KEYSTROKES pressedKey;
		switch (wParam) {
			case KEYSTROKES::left:
			{
				pressedKey = KEYSTROKES::left;
				break;
			}
			case KEYSTROKES::right:
			{
				pressedKey = KEYSTROKES::right;
				break;
			}

			default:
				pressedKey = KEYSTROKES::undefined;
				break;
		}
		return pressedKey;
	}
};