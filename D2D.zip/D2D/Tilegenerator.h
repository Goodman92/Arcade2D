#pragma once

class Tilegenerator {
public:
private:
};